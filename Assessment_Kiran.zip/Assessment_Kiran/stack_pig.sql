a = load '/user/pig/posts.csv' using PigStorage(',') as (id:int, post_type:int, creation_date:chararray, score:int, viewcount:float, owneruser_id:int,title:chararray, answercount:int, commentcount:int );

b = load '/user/pig/comments.csv' USING PigStorage(',') as (id:int, userid:int);

c = load '/user/pig/users.csv' using PigStorage(',') as (id:int,reputation:int,display_name:chararray,loc:chararray,age:int);

d = load '/user/pig/posttypes.csv' USING PigStorage(',') as (id:int, name:chararray);


A. e = join a by id, c by id;
   f= ORDER e by reputation desc;
   g= limit f 1;
   h= foreach g generate display_name,post_type;
   dump h;

B. e= group c ALL;
   f= foreach e generate AVG(c.age);
   dump f;

C. e = join a by id,c by id;
   f = ORDER e by creation_date asc;
   g = limit f 1;
   h = foreach g generate display_name,creation_date;
   dump h;

D. e = join a by id, c by id;
   f= ORDER e by reputation desc;
   g= limit f 1;
   h= foreach g generate displayname,commentcount;

E. e= join a by id, c by id;
   f = ORDER e by score desc; 
   g= limit f 1;
   h= foreach g generate display_name;

F. e = join a by id, c by id;
   f= ORDER e by viewcount desc;
   g= limit f 1;
   h= foreach g generate display_name,owneruser_id;
  dump h;

G. e = join a by id, c by id;
   f= ORDER e by commentcount desc;
   g= limit f 1;
   h= foreach g generate display_name,title;
   dump h;

H. e = join a by id, c by id;
   f= group e by loc;
   g= foreach f generate group, COUNT(e.owneruser_id );
   store g into '/user/pig/';
   h= ORDER g by  $01 desc;
   i= limit h 1;
   dump e;

I. e = join a by id, c by id;
   f= filter E by loc=='India';
   g =group F ALL;
   h= foreach G generate SUM(F.commentcount),SUM(F.answercount),SUM(F.score);
   dump H;
